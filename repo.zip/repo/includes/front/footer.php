<div id="footer">
			<div class="container">
				<p class="text-muted text-center"><?php echo totaldebs(); ?> Packages | <script>var currentTime = new Date();var year = currentTime.getFullYear();document.write(year);</script> © <a style="color:rgb(153,153,153);" href="<?php echo $site_url; ?>"><?php echo $site_nom; ?></a></p>
			</div>
		</div>
		<script src="<?php echo config('url'); ?>js/jquery-latest.min.js"></script>
		<script src="<?php echo config('url'); ?>js/script.js"></script>
		<script src="<?php echo config('url'); ?>js/jquery.lazy.min.js"></script>