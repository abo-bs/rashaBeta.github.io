<?php $pdo = PDO2::getInstance(); ?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<link media="screen" href="css/bootstrap.min.css" rel="stylesheet">
	<!--link rel="stylesheet" href="css/bootstrap.min.css"-->
	<link rel="shortcut icon" href="images/favicon.ico" />
	<style>li.deconnexion>a:hover{background:#e00;color:#fff}#recherche{box-shadow: 0 6px 12px rgba(0,0,0,.176);border: 1px solid rgba(0,0,0,.15);position:absolute;top:43px;left:0;background:#fff;padding:5px 0;border-bottom-left-radius:5px;border-bottom-right-radius:5px;width:175px;}a.resultats{padding:0 20px;color:#000;display:inline-block;width:100%;height:25px;text-align:left;}a.resultats:hover{background:rgb(245,245,245);text-decoration:none}.tabbable-line>.nav-tabs{overflow:hidden}.tabbable-line>.nav-tabs>li{float:none;display:inline-block}.tabbable-line>.nav-tabs>li>a{background:rgba(255,255,255,.8);border-color:#000 #000 transparent;.text-muted();}.tabbable-line>.nav-tabs>li.active>a,.tabbable-line>.nav-tabs>li>a:hover{background:rgba(255,255,255,.5);border-color:#000}.nav-tabs{border-bottom:0 transparent}.navbar-inverse .dropdown-menu{background:#222}.navbar-inverse .dropdown-menu>li>a{color:#999}.navbar-inverse .dropdown-menu>li>a:hover{color:#222}.navbar-inverse .dropdown-menu>li>a:hover,.navbar-inverse .dropdown-menu>li>a:focus{color:#fff;background:#080808}.btn-inverse{background-color:#222;color:#999;border-color:#999}.btn-inverse:hover,.btn-inverse:focus,.btn-inverse:active,.btn-inverse.active,.open .dropdown-toggle.btn-inverse{color:#fff;border-color:#fff}.container .jumbotron{padding:25px 30px 0;background:rgba(255,255,255,.5);box-shadow:0 0 5px #000;border:1px solid}.nopadd{padding:0 !important}body{word-break:break-word;padding-top:50px;background:transparent url("/images/background.png") repeat fixed 0% 0% / contain}.navbar-brand{padding-top:7.5px}.navbar-brand img{height:40px}input[type="file"]{padding:0;border:0}.cleanTop{border-top:0 !important;border-top-right-radius:0 !important;border-top-left-radius:0 !important;margin: 0px !important;padding: 0px 10px !important;border-bottom:0}.tabbable-line.pull-right{margin-right:5px;margin-top:-1px}.tabbable-line>.nav-tabs>li.cleanBottom{margin-bottom:0}.tabbable-line>.nav-tabs>li>a.cleanBottom{border-color:#000 #000 #000;border-radius:0 0 4px 4px;background:rgba(255,255,255,.5);padding:5px}.tabbable-line>.nav-tabs>li>a.cleanBottom.collapsed{background:rgba(255,255,255,.8)}</style>
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only"><?php echo _('Menu'); ?></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="home.php"><img src="/images/logo.png" /></a>
			</div>
			<div class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo _('Menu'); ?></small><b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li class="dropdown-header"><?php echo _('Packages'); ?></li>
							<li><a href="upload.php"><span class="glyphicon glyphicon-plus-sign"></span> <?php echo _('Add a package'); ?></a></li>
							<li><a href="manage-all.php"><span class="glyphicon glyphicon-th-large"></span> <?php echo _('Manage all packages'); ?></a></li>
							<li><a href="manage-sections.php"><span class="glyphicon glyphicon-folder-close"></span> <?php echo _('Manage all sections'); ?></a></li>
							<?php if($membre->_level > 4) { ?>
								<li class="divider"></li>
								<li class="dropdown-header"><?php echo _('Repository'); ?> </li>
								<li><a href="configuration.php"><span class="glyphicon glyphicon-wrench"></span> <?php echo _('Configuration'); ?></a></li>
								<li><a href="release.php"><span class="glyphicon glyphicon-tasks"></span> <?php echo _('Settings'); ?></a></li>
							<?php } ?>
							<li class="divider"></li>
							<li class="dropdown-header"><?php echo _('Others'); ?> </li>
							<li><a href="stats-admin.php"><span class="glyphicon glyphicon-stats"></span> <?php echo _('Statistics'); ?></a></li>
							<li class="divider"></li>
							<li><a href="./"><?php echo _('Back to home.'); ?></a></li>
						</ul>
					</li>
					<form action="manage-all.php" class="navbar-form navbar-left" style="margin-left:0;margin-right:0" method="get" role="search">
						<div class="form-group" style="position:relative"><input autocapitalize="off" autocorrect="off" autocomplete="off" id="resultat" type="text" onkeyup="showHint(this.value)" class="form-control" placeholder="<?php echo _('Search').'...'; ?>" name="s" /><span id="recherche-dyna" class="hidden-xs"></span></div>
						<button type="submit" class="btn btn-inverse hidden-sm hidden-xs"><span class="glyphicon glyphicon-search"></span></button>
					</form>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php if($membre->_level > 1) { ?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo _('Users'); ?> <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="new-membre.php"><span class="glyphicon glyphicon-plus"></span> <?php echo _('Add a member'); ?></a></li>
							<?php if($membre->_level > 3) { ?>
							<li><a href="membres.php"><span class="glyphicon glyphicon-user"></span> <?php echo _('Manage members'); ?> </a></li>
							<li><a href="users.php"><span class="glyphicon glyphicon-phone"></span> <?php echo _('Manage UDIDs'); ?> </a></li>
							<?php } ?>
						</ul>
					</li>
					<?php } ?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $membre->_pseudo; ?> <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="downloads.php"><span class="glyphicon glyphicon-download"></span> <?php echo _('Your downloads'); ?></a></li>
							<li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> <?php echo _('Settings'); ?> </a></li>
							<li class="deconnexion"><a href="login.php?action=logout&amp;token=<?php echo $membre->_token; ?>"><span class="glyphicon glyphicon-log-out"></span> <?php echo _('Logout'); ?> </a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</nav>