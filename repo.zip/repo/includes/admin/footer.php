<footer><p class="text-center text-primary">Copyright <script>var currentTime = new Date();var year = currentTime.getFullYear();document.write(year);</script> &copy; <?php echo $site_nom; ?></p></footer>
	<script src="<?php echo config('url'); ?>js/jquery-latest.min.js"></script>
	<script src="<?php echo config('url'); ?>js/script.js"></script>
	<?php if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'mobile')) {}else{ ?>
		<script>function showHint(str){if(str.length<1){document.getElementById("recherche-dyna").innerHTML="";return;}else{var xmlhttp = new XMLHttpRequest();xmlhttp.onreadystatechange = function() {if(xmlhttp.readyState==4 && xmlhttp.status==200){document.getElementById("recherche-dyna").innerHTML=xmlhttp.responseText;}};xmlhttp.open("GET","ajax/gethint.php?q="+encodeURIComponent(str),true);xmlhttp.send();}}</script>
	<?php } ?>