<?php require_once('functions.php');

class Paquet {
	private $_id, $_online, $_package;
	private static $_tablePaquet = array('id', 'package', 'name', 'version', 'description', 'author', 'section', 'pre-depends', 'depends', 'conflicts', 'installed-size', 'replaces', 'priority', 'icon', 'size', 'md5sum', 'essential');
	private static $_tableInfos = array('description1', 'images', 'changelog', 'online', 'date', 'date_update', 'total_download', 'total_votes', 'total_value', 'used_ips', 'id_membre', 'tweet', 'compatible_device', 'compatible_ios', 'visited_ips', 'visits');

	public function getId() {
		return isset($this->_id) ? $this->_id : false;
	}
	public function __construct($id) {
		$this->_id = strtolower(addslashes(@trim($id)));
	}
	public function verifier_deb() {
		return file_exists('debs/org.goldencydia.'.$this->_id.'/org.goldencydia.'.$this->_id.'.deb');
	}
	public function verifier_fiche(){
		return $this->package_control('package');
	}
	public function verifier_etat(){
		return $this->package_control('online');
	}
	public function compter_telechargement($user){
		if(!empty($this->_id)) {
			$version = $this->package_control('Version');
			$pdo = PDO2::getInstance();
			$req = $pdo->prepare('INSERT INTO download (user, package, version, date) VALUES (:user, :id, :version, CURRENT_TIMESTAMP)');
			$req1 = $pdo->prepare("INSERT INTO description_meta (id, total_download) VALUES (:id, 0)
			ON DUPLICATE KEY UPDATE total_download = total_download + 1");
			$req2 = $pdo->prepare("INSERT INTO users (id, total_download) VALUES (:id, 1)
			ON DUPLICATE KEY UPDATE total_download = total_download + 1");
			try {
				$req->execute(array(':user' => $user, ':id' => $this->_id, ':version' => $version));
				$req->closeCursor();
				$req1->execute(array(':id' => $this->_id));
				$req1->closeCursor();
				$req2->execute(array(':id' => $user));
				$req2->closeCursor();
				$pdo = PDO2::closeInstance();
			} catch(Exception $e) {
				file_put_contents('testv2.txt', serialize($e).'\n\r'.serialize($_GET).'\r\n'.serialize($_SERVER));
				$req->closeCursor();
				$req1->closeCursor();
				$req2->closeCursor();
				$pdo = PDO2::closeInstance();
			}
		} else
			file_put_contents('testv2.txt', serialize($_GET).'\r\n'.serialize($_SERVER));
	}
	public function total_telechargement(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT COUNT(id) FROM download WHERE package = :id LIMIT 1');
		try {
			$req->execute(array(':id' => $this->_id));
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return $retour;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return 0;
		}
	}
	public function details_telechargement(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT DISTINCT(version), COUNT(id) AS telechargement FROM download WHERE package = :id GROUP BY package, version ORDER BY date DESC');
		try {
			$req->execute(array(':id' => $this->_id));
			$retour = $req->fetchAll(PDO::FETCH_ASSOC);
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return $retour;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	public function package_control($ligne) {
		$pdo = PDO2::getInstance();
		$req = (is_array($ligne)) ? implode('`, `', $ligne) : $ligne;
		$req = $pdo->prepare("SELECT `$req` FROM description INNER JOIN description_meta ON description.id = description_meta.id WHERE description.id = :id LIMIT 1");
		try {
			$req->execute(array(':id' => $this->_id));
			if(is_array($ligne))
				$retour = $req->fetch(PDO::FETCH_ASSOC);
			else
				$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			if($retour != NULL && !empty($retour))
				return $retour;
			else
				return false;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	public function changer_control($text, $ligne) {
		$pdo = PDO2::getInstance();
		if(empty($text) || $text == false)
			$text = '';
		if(in_array(strtolower($ligne), self::$_tablePaquet))
			$table = 'description';
		elseif(in_array(strtolower($ligne), self::$_tableInfos))
			$table = 'description_meta';
		else
			return;
		$req = $pdo->prepare("INSERT INTO $table (id, `$ligne`) VALUES (:id, :text)
		ON DUPLICATE KEY UPDATE `$ligne` = :text");
		try {
			$req->execute(array(':id' => $this->_id, ':text' => $text));
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		} catch (Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		}
	}
	public function rating_bar($langue_vote, $langue_votes, $static = '') {
		if (!$static)
			$static = FALSE;
		$numbers = $this->package_control(array('total_votes', 'total_value', 'used_ips'));
		if ($numbers['total_votes'] < 1)
			$count = 0;
		else
			$count = $numbers['total_votes'];
		$current_rating = (isset($numbers['total_value'])) ? $numbers['total_value'] : '1';
		$tense = ($count == 1) ? $langue_vote : $langue_votes;
		$used = (isset($numbers['used_ips'])) ? $numbers['used_ips'] : 'a:0:{}';
		$voted = (@in_array(getIp(), unserialize($used))) ? 1 : 0;
		if ($static == 'static')
			return '<strong>'.($count > 0 ? @number_format($current_rating / $count, 1) : '0.0').'</strong>/5 ('.$count.' '.$tense.')';
		else {
			$rater = '<div id="unit_long'.$this->_id.'" style="height:55px">';
			$rater .= '<ul id="unit_ul_'.$this->_id.'" class="unit-rating" style="width:150px">';
			$rater .= '<li class="current-rating" style="width:'.@number_format($current_rating / $count * 30, 2).'px;"></li>';
			if(!$voted) {
				for ($ncount = 1; $ncount <= 5; $ncount++) {
					$rater .= '<li><a class="r'.$ncount.'-unit rater"  href="#" onclick="sndReq('.$ncount.', \''.$this->_id.'\', \''.getIp().'\');return false;" style="cursor:pointer" rel="nofollow" title="'.$ncount.' / 5">'.$ncount.'</a></li>';
				}
			}
			$rater .= '</ul><div class="text-center';
			if($voted)
				$rater .= ' voted';
			$rater .= '"><strong>'.($count > 0 ? @number_format($current_rating / $count, 2) : '0.00').'</strong>/5 ('.$count.' '.$tense.').</div></div>';
			$rater .= ($count > 0) ? '<div itemtype="http://schema.org/AggregateRating" itemscope="" itemprop="aggregateRating" style="display:none;"><meta itemprop="bestRating" content="5" /><meta itemprop="ratingValue" content="'.@number_format($current_rating / $count, 2).'" /><meta content="'.$count.'" itemprop="ratingCount" /></div>' : '';
			return $rater;
		}
	}
	public function tracker() {
		if(!isBot())
			$this->changer_control($this->package_control('visits') + 1, 'visits');
	}
	public function description_paquet() {
		$test = $this->package_control('description1');
		if(!empty($test))
			return $test;
		else
			return $this->package_control('Description');
	}
	public function icone_paquet(){
		if(file_exists('images/debs/'.$this->_id.'.png'))
			return config('url').'images/debs/'.$this->_id.'.png';
		else
			return config('url').'images/sections/'.preg_replace('/[\/_|+ -]+/', '-', strtolower(trim($this->package_control('Section')))).'.png';
	}
	public function screen_paquet($tableau) {
		if(is_dir('images/debs/'.$this->_id.'/')) {
			$objects = scandir('images/debs/'.$this->_id.'/');
			$retour = array();
			foreach ($objects as $object) {
				if ($object != '.' && $object != '..')
					$retour[] .= config('url').'images/debs/'.$this->_id.'/'.$object;
			}
			reset($objects);
			if($tableau)
				return $retour;
			else
				return count($retour);
		} else
			return false;
	}
	public function supprimer_cache() {
	}
	private function supprimerFiche() {
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('UPDATE download SET package = NULL WHERE package = :id');
		$suppr_meta = $pdo->prepare("DELETE FROM description_meta WHERE id = :id");
		$suppr = $pdo->prepare("DELETE FROM description WHERE id = :id");
		try {
			$suppr_meta->execute(array(':id' => $this->_id));
			$suppr_meta->closeCursor();
			$req->execute(array(':id' => $this->_id));
			$req->closeCursor();
			$suppr->execute(array(':id' => $this->_id));
			$suppr->closeCursor();
			$pdo = PDO2::closeInstance();
		} catch(Exception $e) {
			$suppr_meta->closeCursor();
			$req->closeCursor();
			$suppr->closeCursor();
			$pdo = PDO2::closeInstance();
		}
	}
	public function supprimer_definitivement() {
		if(!empty($this->_id)) {
			rrmdir('debs/org.goldencydia.'.$this->_id);
			if(file_exists('images/debs/'.$this->_id.'.png'))
				unlink('images/debs/'.$this->_id.'.png');
			if(is_dir('images/debs/'.$this->_id))
				rrmdir('images/debs/'.$this->_id);
			$this->supprimerFiche();
		} elseif(is_dir('debs/org.goldencydia.'.$this->_id)) {
			rrmdir('debs/org.goldencydia.'.$this->_id);
			if(file_exists('images/debs/'.$this->_id.'.png'))
				unlink('images/debs/'.$this->_id.'.png');
			$this->supprimerFiche();
			$this->supprimer_cache();
		}
	}
}