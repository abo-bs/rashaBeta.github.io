<?php require_once('pdo.class.php');

	function config($search) {
		require_once('includes/config.php');
		global $config;
		return $config[$search];
	}
	function package_control($fichier, $search) {
		if(file_exists($fichier)) {
			$fichier = file($fichier);
			foreach ($fichier as $ligne) {
				$lenght = strlen($search) + 2;
				if(stristr($search.': ', substr($ligne,0,$lenght)))
					$found = trim(substr($ligne, $lenght));
			}
		}
		if(isset($found))
			return $found;
		else
			return false;
	}
	function type_device() {
		if (stripos($_SERVER['HTTP_USER_AGENT'],'iPhone')  !== false)
			return 'iPhone';
		elseif (stripos($_SERVER['HTTP_USER_AGENT'],'iPad') !== false)
			return 'iPad';
		elseif (stripos($_SERVER['HTTP_USER_AGENT'],'iPod') !== false)
			return 'iPod';
		else
			return 'unknow device';
	}
	function type_ios() {
		return substr(str_replace('_', '.', preg_replace("/(.*) OS ([0-9])(_)?([0-9])?(_)?([0-9])?(.*)/", "$2$3$4$5$6", $_SERVER['HTTP_USER_AGENT'])), 0, 5);
	}
	function nom_appareil($nom) {
		switch($nom) {
			case 'iphone8,2':
				return 'iPhone 6s+';
			case 'iphone8,1':
				return 'iPhone 6s';
			case 'iphone7,2':
				return 'iPhone 6';
			case 'iphone7,1':
				return 'iPhone 6 Plus';
			case 'iphone6,1':
			case 'iphone6,2':
				return 'iPhone 5S';
			case 'iphone5,3':
			case 'iphone5,4':
				return 'iPhone 5C';
			case 'iphone5,1':
			case 'iphone5,2':
				return 'iPhone 5';
			case 'iphone4,1':
				return 'iPhone 4S';
			case 'iphone3,1':
			case 'iphone3,2':
			case 'iphone3,3':
				return 'iPhone 4';
			case 'iphone2,1':
				return 'iPhone 3GS';
			case 'iphone1,2':
				return 'iPhone 3G';
			case 'iphone1,1':
				return 'iPhone 2G';
			case 'ipad5,3':
			case 'ipad5,4':
				return 'iPad Air 2';
			case 'ipad5,1':
			case 'ipad5,2':
				return 'iPad Mini 4';
			case 'ipad4,7':
			case 'ipad4,8':
			case 'ipad4,9':
				return 'iPad Mini 3';
			case 'ipad4,4':
			case 'ipad4,5':
			case 'ipad4,6':
				return 'iPad Mini 2';
			case 'ipad4,1':
			case 'ipad4,2':
			case 'ipad4,3':
				return 'iPad Air';
			case 'ipad3,4':
			case 'ipad3,5':
			case'ipad3,6':
				return 'iPad 4';
			case 'ipad3,1':
			case 'ipad3,2':
			case 'ipad3,3':
				return 'iPad 3';
			case 'ipad2,5':
			case 'ipad2,6':
			case 'ipad2,7':
				return 'iPad Mini';
			case 'ipad2,1':
			case 'ipad2,2':
			case 'ipad2,3':
			case 'ipad2,4':
				return 'iPad 2';
			case 'ipad1,1':
				return 'iPad 1';
			case 'ipod7,1':
				return 'iPod Touch 6';
			case 'ipod5,1':
				return 'iPod Touch 5';
			case 'ipod4,1':
				return 'iPod Touch 4';
			case 'ipod3,1':
				return 'iPod Touch 3';
			case 'ipod2,1':
				return 'iPod Touch 2';
			case 'ipod1,1':
				return 'iPod Touch 1';
			default:
				return $nom.' ?';
		}
	}
	function totaldebs() {
		if(file_exists('includes/cache/totaldebs.txt'))
			include('includes/cache/totaldebs.txt');
		else {
			$pdo = PDO2::getInstance();
			$req = $pdo->prepare('SELECT COUNT(description.id) FROM description INNER JOIN description_meta ON description.id = description_meta.id WHERE online = true');
			try {
				$req->execute();
				$retour = $req->fetchColumn();
				$req->closeCursor();
				$pdo = PDO2::closeInstance();
				file_put_contents('includes/cache/totaldebs.txt', @number_format($retour, 0, ', ', ' '));
				return @number_format($retour, 0, ', ', ' ');
			} catch(Exception $e) {
				$req->closeCursor();
				$pdo = PDO2::closeInstance();
				return 0;
			}
		}
	}
	function totalMembre() {
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT COUNT(id) FROM membre');
		try {
			$req->execute();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return @number_format($retour, 0, ', ', ' ');
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return 0;
		}
	}
	function total_download($cleanCache = false){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT COUNT(id) FROM download');
		try {
			$req->execute();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return @number_format($retour, 0, ', ', ' ');
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return 0;
		}
	}
	function totalDownload(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT SUM(total_download) FROM description_meta');
		try {
			$req->execute();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return @number_format($retour, 0, ', ', ' ');
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return 0;
		}
	}
	function total_udid(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT COUNT(udid) FROM users');
		try {
			$req->execute();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return @number_format($retour, 0, ', ', ' ');
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return 0;
		}
	}
	function compter_udid(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('INSERT INTO users (udid, date, firmware, device, ip, date_update) VALUES (:udid, CURRENT_TIMESTAMP, :firmware, :device, :ip, CURRENT_TIMESTAMP)
		ON DUPLICATE KEY UPDATE firmware = :firmware, device = :device, ip = :ip, date_update = CURRENT_TIMESTAMP');
		try {
			$req->execute(array(':udid' => strtolower(trim($_SERVER['HTTP_X_UNIQUE_ID'])), ':firmware' => strtolower(trim($_SERVER['HTTP_X_FIRMWARE'])), ':device' => nom_appareil(strtolower(trim($_SERVER['HTTP_X_MACHINE']))), ':ip' => getIp()));
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		}
	}
	function verifier_udid($udid) {
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT id FROM users WHERE udid = :udid AND banni = 0 LIMIT 1');
		try {
			$req->execute(array(':udid' => strtolower($udid)));
			$count = $req->rowCount();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			if($count === 1)
				return $retour;
			else
				return false;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	function last_visite_udid($udid) {
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT date_update FROM users WHERE udid = :udid AND banni = 0 LIMIT 1');
		try {
			$req->execute(array(':udid' => strtolower($udid)));
			$count = $req->rowCount();
			$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			if($count === 1)
				return $retour;
			else
				return false;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	function cours_download(){
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('SELECT description.id, Name, Section, download.date FROM download INNER JOIN description ON download.package = description.id INNER JOIN description_meta ON description.id = description_meta.id WHERE online = true ORDER BY download.date DESC LIMIT 0, 5');
		try {
			$req->execute();
			$retour = $req->fetchAll(PDO::FETCH_ASSOC);
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return $retour;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	function DirectorySize($path){
		$bytestotal = 0;
		$path = realpath($path);
		if($path !== false) {
			foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $object) {
				$bytestotal += $object->getSize();
			}
		}
		return $bytestotal;
	}
	function getIp() {
		if(getenv('REMOTE_ADDR'))
			return getenv('REMOTE_ADDR');
		else
			return;
	}
	function isBot() {
		$botlist = array("Teoma", "alexa", "froogle", "Gigabot", "inktomi", "looksmart", "URL_Spider_SQL", "Firefly", "NationalDirectory", "Ask Jeeves", "TECNOSEEK", "InfoSeek", "WebFindBot", "girafabot", "crawler", "www.galaxy.com", "Googlebot", "Scooter", "Slurp", "msnbot", "appie", "FAST", "WebBug", "Spade", "ZyBorg", "rabaz", "Baiduspider", "Feedfetcher-Google", "TechnoratiSnoop", "Rankivabot", "Mediapartners-Google", "Sogou web spider", "WebAlta Crawler","TweetmemeBot", "Butterfly","Twitturls","Me.dium","Twiceler");
		foreach($botlist as $bot) {
			if(strpos($_SERVER['HTTP_USER_AGENT'], $bot) !== false)
				return true;
		}
		return false;
	}
	function rrmdir($dir) {
		if(is_dir($dir)) {
			cchmod($dir, 0777);
			$objects = @scandir($dir);
			foreach ($objects as $object) {
				if ($object != '.' && $object != '..') {
					if(filetype($dir.'/'.$object) == 'dir')
						rrmdir($dir.'/'.$object);
					else
						@unlink($dir.'/'.$object);
				}
			}
			reset($objects);
			@rmdir($dir);
		} else
			@unlink($dir);
	}
	function cchmod($dir, $value) {
		if(is_dir($dir)) {
			@chmod($dir, $value);
			$objects = @scandir($dir);
			foreach ($objects as $object) {
				if ($object != '.' && $object != '..') {
					if(filetype($dir.'/'.$object) == 'dir')
						cchmod($dir.'/'.$object, $value);
					else
						@chmod($dir.'/'.$object, $value);
				}
			}
			reset($objects);
		}
	}
	function taille_fichier($path) {
		$units = array( 'B', 'KB', 'MB', 'GB', 'TB');
		$power = $path > 0 ? floor(log($path, 1024)) : 0;
		return @number_format($path / pow(1024, $power), 2, '.', ',').' '.$units[$power];
	}
	function tweet($message) {
//		require_once('includes/twitteroauth.php');
		return false;
	}
	function print_timeago($past, $now = "now") {
		$past = strtotime($past);
		$now = strtotime($now);
		$timeAgo = "";
		$timeDifference = $now - $past;
		if($timeDifference <= 29) {
			$timeAgo = _('Less than a minute');
		} else if($timeDifference > 29 && $timeDifference <= 89) {
			$timeAgo = _('1 minute');
		} else if($timeDifference > 89 && $timeDifference <= ((60 * 44) + 29)) {
			$minutes = floor($timeDifference / 60);
			$timeAgo = $minutes.' '._('minutes');
		} else if($timeDifference > ((60 * 44) + 29) && $timeDifference < ((60 * 89) + 29)) {
			$timeAgo = _('About 1 hour');
		} else if($timeDifference > ((60 * 89) + 29) && $timeDifference <= ((3600 * 23) + (60 * 59) + 29)) {
			$hours = floor($timeDifference / 3600);
			$timeAgo = $hours.' '._('hours');
		} else if($timeDifference > ((3600 * 23) + (60 * 59) + 29) && $timeDifference <= ((3600 * 47) + (60 * 59) + 29)) {
			$timeAgo = _('1 day');
		} else if($timeDifference > ((3600 * 47) + (60 * 59) + 29) && $timeDifference <= ((86400 * 29) + (3600 * 23) + (60 * 59) + 29)) {
			$days = floor($timeDifference / 86400);
			$timeAgo = $days.' '._('days');
		} else if($timeDifference > ((86400 * 29) + (3600 * 23) + (60 * 59) + 29) && $timeDifference <= ((86400 * 59) + (3600 * 23) + (60 * 59) + 29)) {
			$timeAgo = _('About 1 month');
		} else if($timeDifference > ((86400 * 59) + (3600 * 23) + (60 * 59) + 29) && $timeDifference < 31104000) {
			$months = round($timeDifference / 2592000);
			if($months == 1) {
				$months = 2;
			}
			$timeAgo = $months.' '._('months');
		} else if($timeDifference >= 31104000 && $timeDifference < (31104000 * 2)) {
			$timeAgo = _('About 1 year');
		} else {
			$years = floor($timeDifference / 31104000);
			$timeAgo = $years.' '._('years');
		}
		return $timeAgo;
	}
	function print_number($number) {
		$units = array( '', 'K', 'M', 'B');
		$power = $number > 0 ? floor(log($number, 1000)) : 0;
		if($power > 0) {
			$number = @number_format($number / pow(1000, $power), 2, ',', ' ');
			if(substr($number, -3) == ',00')
				return substr($number, 0, -3).' '.$units[$power];
			elseif(substr($number, -1) == '0')
				return substr($number, 0, -1).' '.$units[$power];
			else
				return $number.' '.$units[$power];
		} else
			return @number_format($number / pow(1000, $power), 0, '', '');
	}
	function translation() {
		if(empty($_COOKIE['language']))
			$lang = autotraduction();
		else
			$lang = $_COOKIE['language'];
		switch($lang) {
			case 'ar':
				$lang = 'ar_AE';
				break;
			case 'de':
				$lang = 'de_DE';
				break;
			case 'el':
				$lang = 'el_GR';
				break;
			case 'en':
				$lang = 'en_US';
				break;
			case 'es':
				$lang = 'es_ES';
				break;
			case 'fr':
				$lang = 'fr_FR';
				break;
			case 'it':
				$lang = 'it_IT';
				break;
			case 'pt':
				$lang = 'pt_PT';
				break;
			case 'ru':
				$lang = 'ru_RU';
				break;
			case 'th':
				$lang = 'th_TH';
				break;
			case 'vi':
				$lang = 'vi_VN';
				break;
			case 'zh':
				$lang = 'zh_CN';
				break;
			default:
				$lang = 'en_US';
		}
		putenv("LANG=$lang.UTF-8");
		setlocale(LC_ALL, "$lang.UTF-8");
		bindtextdomain($lang, 'includes/lang');
		textdomain($lang);
		return $lang;
	}
	function autotraduction() {
		if( function_exists('locale_accept_from_http') ) {
    		$locale = locale_accept_from_http($_SERVER['HTTP_ACCEPT_LANGUAGE']);
		} else {
		    $explodeLocale = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
		    $locale = empty($explodeLocale[0])?'en_US':str_replace('-', '_', $explodeLocale[0]);
		}
		switch($locale){
			case 'ar_AR':
			case 'ar':
				$lang = 'ar';
				$other = false;
				break;
			case 'de_DE':
			case 'de':
				$lang = 'de';
				$other = false;
				break;
			case 'el_GR':
			case 'el':
				$lang = 'el';
				$other = false;
				break;
			case 'en_EN':
			case 'en_US':
			case 'en_GB':
			case 'en':
				$lang = 'en';
				$other = false;
				break;
			case 'es_ES':
			case 'es':
				$lang = 'es';
				$other = false;
				break;
			case 'fr_FR':
			case 'fr':
				$lang = 'fr';
				$other = false;
				break;
			case 'it_IT':
			case 'it':
				$lang = 'it';
				$other = false;
				break;
			case 'pt_BR':
			case 'pt_PT':
			case 'pt':
				$lang = 'pt';
				$other = false;
				break;
			case 'ru_RU':
			case 'ru':
				$lang = 'ru';
				$other = false;
				break;
			case 'th_TH':
			case 'th':
				$lang = 'th';
				$other = false;
				break;
			case 'vi_VN':
			case 'vi':
				$lang = 'vi';
				$other = false;
				break;
			case 'zh_CN':
			case 'zh_HK':
			case 'zh':
				$lang = 'zh';
				$other = false;
				break;
			default:
				$lang = 'en';
				$other = true;
		}
		$expire = time() + 3600 * 24 * 30;
		if($other)
			setcookie('other', $other, $expire, '/');
		setcookie('language', $lang, $expire, '/');
		return $lang;
	}