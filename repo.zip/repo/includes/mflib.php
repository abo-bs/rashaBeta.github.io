<?php
class mflib
{
    public $appId = '40899';
    public $apiKey = 'aaw8gjo2j2msv7r3el73rwjz7877vfku5a8vkgzg';
    public $email = 'contact@xarold.com';
    public $password = 'Loading456';
    public $fbAccessToken;
    public $useCurl = false;
    public $userAgent = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)";
    protected $responseFormat = "json";
    protected $apiUrl = array(
        "FILE_COLLABORATE" => "http://www.mediafire.com/api/file/collaborate.php",
        "FILE_CONFIGURE_ONE_TIME_DOWNLOAD" => "http://www.mediafire.com/api/file/configure_one_time_download.php",
        "FILE_COPY" => "http://www.mediafire.com/api/file/copy.php",
        "FILE_DELETE" => "http://www.mediafire.com/api/file/delete.php",
        "FILE_GET_INFO" => "http://www.mediafire.com/api/file/get_info.php",
        "FILE_GET_LINKS" => "http://www.mediafire.com/api/file/get_links.php",
        "FILE_MOVE" => "http://www.mediafire.com/api/file/move.php",
        "FILE_ONE_TIME_DOWNLOAD" => "http://www.mediafire.com/api/file/one_time_download.php",
        "FILE_UPDATE" => "http://www.mediafire.com/api/file/update.php",
        "FILE_UPDATE_FILE" => "http://www.mediafire.com/api/file/update_file.php",
        "FILE_UPDATE_PASSWORD" => "http://www.mediafire.com/api/file/update_password.php",
        "FILE_UPLOAD" => "http://www.mediafire.com/api/upload/upload.php",
        "FILE_UPLOAD_CONFIG" => "http://www.mediafire.com/basicapi/uploaderconfiguration.php",
        "FILE_UPLOAD_GETTYPE" => "http://www.mediafire.com/basicapi/getfiletype.php",
        "FILE_UPLOAD_POLL" => "http://www.mediafire.com/api/upload/poll_upload.php",
        "FOLDER_ATTACH_FOREIGN" => "http://www.mediafire.com/api/folder/attach_foreign.php",
        "FOLDER_CREATE" => "http://www.mediafire.com/api/folder/create.php",
        "FOLDER_DELETE" => "http://www.mediafire.com/api/folder/delete.php",
        "FOLDER_DETACH_FOREIGN" => "http://www.mediafire.com/api/folder/detach_foreign.php",
        "FOLDER_GET_CONTENT" => "http://www.mediafire.com/api/folder/get_content.php",
        "FOLDER_GET_DEPTH" => "http://www.mediafire.com/api/folder/get_depth.php",
        "FOLDER_GET_INFO" => "http://www.mediafire.com/api/folder/get_info.php",
        "FOLDER_GET_REVISION" => "http://www.mediafire.com/api/folder/get_revision.php",
        "FOLDER_GET_SIBLINGS" => "http://www.mediafire.com/api/folder/get_siblings.php",
        "FOLDER_MOVE" => "http://www.mediafire.com/api/folder/move.php",
        "FOLDER_SEARCH" => "http://www.mediafire.com/api/folder/search.php",
        "FOLDER_UPDATE" => "http://www.mediafire.com/api/folder/update.php",
        "SYSTEM_GET_EDITABLE_MEDIA" => "http://www.mediafire.com/api/system/get_editable_media.php",
        "SYSTEM_GET_INFO" => "http://www.mediafire.com/api/system/get_info.php",
        "SYSTEM_GET_MIME_TYPES" => "http://www.mediafire.com/api/system/get_mime_types.php",
        "SYSTEM_GET_SUPPORTED_MEDIA" => "http://www.mediafire.com/api/system/get_supported_media.php",
        "SYSTEM_GET_VERSION" => "http://www.mediafire.com/api/system/get_version.php",
        "USER_ACCEPT_TOS" => "http://www.mediafire.com/api/user/accept_tos.php",
        "USER_FETCH_TOS" => "http://www.mediafire.com/api/user/fetch_tos.php",
        "USER_GET_INFO" => "http://www.mediafire.com/api/user/get_info.php",
        "USER_GET_LOGIN_TOKEN" => "https://www.mediafire.com/api/user/get_login_token.php",
        "USER_GET_SESSION_TOKEN" => "https://www.mediafire.com/api/user/get_session_token.php",
        "USER_LOGIN" => "http://www.mediafire.com/api/user/login_with_token.php",
        "USER_MYFILES" => "http://www.mediafire.com/api/user/myfiles.php",
        "USER_MYFILES_REVISION" => "http://www.mediafire.com/api/user/myfiles_revision.php",
        "USER_REGISTER" => "https://www.mediafire.com/api/user/register.php",
        "USER_RENEW_SESSION_TOKEN" => "http://www.mediafire.com/api/user/renew_session_token.php",
        "USER_UPDATE" => "http://www.mediafire.com/api/user/update.php",
        "MEDIA_CONVERSION" => "http://www.mediafire.com/conversion_server.php"
    );
    protected $actions = array();
    protected $mcStatusCode = array(
        "200" => "Conversion is ready. The pdf is sent with the response",
        "202" => "Request is accepted and in progress",
        "204" => "Unable to fulfill request. The document will not be converted",
        "400" => "Bad request. Check your arguments",
        "404" => "Unable to find file from quickkey"
    );
    protected $mcSizeId = array(
        "d" => array("0", "1", "2"),
        "i" => array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f")
    );
    protected $uploadResult = array(
        -80 => "Upload Key not found", 
        -20 => "Invalid Upload Key",
        0 => "Success"
    );
    protected $uploadStatus = array(
        0 => "Unknown or no status available for this key", 
        2 => "Key is ready for use",
        3 => "Upload is in progress",
        4 => "Upload is completed",
        5 => "Waiting for verification",
        6 => "Verifying File",
        11 => "Finished verification",
        99 => "No more requests for this key"
    );
    protected $uploadFileError = array(
        1 => "File is larger than the maximum filesize allowed",
        2 => "File size cannot be 0",
        3 => "Found a bad RAR file",
        4 => "Found a bad RAR file",
        5 => "Virus found",
        6 => "Unknown internal error",
        7 => "Unknown internal error",
        8 => "Unknown internal error",
        9 => "Found a bad RAR file",
        12 => "Failed to insert data into database",
        13 => "File name already exists in the same parent folder, skipping",
        14  => "Destination folder does not exist"
    );
    protected $httpResponseHeader;
    public function __construct()
    {
        $arguments = func_get_args();

        if (count($arguments) >= 2)
        {
            $this->appId = $arguments[0];
            $this->apiKey = $arguments[1];

            if (count($arguments) >= 4)
            {
                $this->email = $arguments[2];
                $this->password = $arguments[3];
            }
        }
    }

    public function getContents($url, $httpOptions = null, $returnRaw = false)
    {
	ini_set('memory_limit', -1);
        if ($this->useCurl === true && !isset($httpOptions["file"]))
        {
            $handle = curl_init();

            $options = array(
                CURLOPT_URL => $url,
                CURLOPT_FRESH_CONNECT => true,
                CURLOPT_HEADER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_USERAGENT => $this->userAgent
            );

            $requestMethod = "GET";
            if (isset($httpOptions["method"]) && is_string($httpOptions["method"]))
            {
                $requestMethod = strtoupper(trim($httpOptions["method"]));
                $options[CURLOPT_CUSTOMREQUEST] = $requestMethod;
            }

            if ($requestMethod == "POST" && isset($httpOptions["content"]))
            {
                $options[CURLOPT_POSTFIELDS] = $httpOptions["content"];
            }

            if (isset($httpOptions["protocol_version"]) && $httpOptions["protocol_version"] == "1.0")
            {
                $options[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_0;
            } else
            {
                $options[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
            }

            $timeout = 30;
            if (isset($httpOptions["timeout"]) && is_int($httpOptions["timeout"]))
            {
                $options[CURLOPT_TIMEOUT] = $timeout;
            }

            if (isset($httpOptions["header"]) && !empty($httpOptions["header"]))
            {
                if (is_string($httpOptions["header"]))
                {
                    $requestHeader = explode("\r\n", $httpOptions["header"]);
                } else
                {
                    $requestHeader = $httpOptions["header"];
                }

                $options[CURLOPT_HTTPHEADER] = $requestHeader;
            }

            curl_setopt_array($handle, $options);
            $response = curl_exec($handle);

            if (curl_errno($handle))
            {
                $this->showError("cURL error : " . curl_error($handle));
                curl_close($handle);
                return false;
            }

            curl_close($handle);
        } else
        {
            $components = parse_url($url);

            $timeout = 30;
            if (isset($httpOptions["timeout"]) && is_int($httpOptions["timeout"]))
            {
                $timeout = $httpOptions["timeout"];
            }

            if ($components["scheme"] == "https")
            {
                $handle = @fsockopen("ssl://" . $components["host"], 443, $errno, $errstr, $timeout);
            } else
            {
                $handle = @fsockopen($components["host"], 80, $errno, $errstr, $timeout);
            }

            if (!$handle)
            {
                $this->showError("Socket error : " . $errstr);
                return false;
            } else
            {
                $requestMethod = "GET";
                if (isset($httpOptions["method"]) && is_string($httpOptions["method"]))
                {
                    $requestMethod = strtoupper(trim($httpOptions["method"]));
                }

                $protocol_version = "1.1";
                if (isset($httpOptions["protocol_version"]) && is_string($httpOptions["protocol_version"]))
                {
                    $protocol_version = trim($httpOptions["protocol_version"]);
                }

                $query = "";
                if (isset($components["query"]))
                {
                    $query = "?" . $components["query"];
                }

                $response = "";
                $header = $requestMethod . " " . $components["path"] . $query . " HTTP/" . $protocol_version . "\r\n";
                $header .= "Host: " . $components["host"] . "\r\n";
                $header .= "Connection: Close\r\n";
                $header .= "User-agent: " . $this->userAgent . "\r\n";

                if (isset($httpOptions["header"]) && !empty($httpOptions["header"]))
                {
                    if (is_array($httpOptions["header"]))
                    {
                        $requestHeader = implode("\r\n", $httpOptions["header"]);
                    } else
                    {
                        $requestHeader = $httpOptions["header"];
                    }

                    $header .= $requestHeader . "\r\n";
                }

                $data = "";

                if ($requestMethod == "POST")
                {
                    if (isset($httpOptions["file"]) && !empty($httpOptions["file"]))
                    {
                        srand((double) microtime() * 1000000);
                        $boundary = "---------------------------" . substr(md5(rand(0, 32000)), 0, 11);
                        $header .= "Content-Type: multipart/form-data, boundary=$boundary\r\n";

                        if (isset($httpOptions["content"]))
                        {
                            if (is_string($httpOptions["content"]))
                            {
                                $httpPostContent = parse_str($httpOptions["content"]);
                            } else
                            {
                                $httpPostContent = $httpOptions["content"];
                            }
                        }

                        if (!empty($httpPostContent))
                        {
                            foreach($httpPostContent as $name => $value)
                            {
                                $data .= "--$boundary\r\n";
                                $data .= "Content-Disposition: form-data; name=\"" . $name . "\"\r\n";
                                $data .= "\r\n" . $value . "\r\n";
                                $data .= "--$boundary\r\n";
                            }
                        } else
                        {
                            $data .= "--$boundary\r\n";
                        }

                        $pathname = $httpOptions["file"]["path"];
                        $basename = pathinfo($pathname, PATHINFO_BASENAME);

                        $fileHandle = fopen($pathname, "r");
                        $contents = fread($fileHandle, filesize($pathname));
                        fclose($fileHandle);

                        $data .= "Content-Disposition: form-data; name=\"" . $httpOptions["file"]["name"] . "\"; filename=\"$basename\"\r\n";
                        $data .= "Content-Type: " . $httpOptions["file"]["type"] . "\r\n\r\n";
                        $data .= $contents . "\r\n";
                        $data .= "--$boundary--\r\n";
                        $header .= "Content-Length: " . strlen($data) . "\r\n";
                    } else
                    {
                        if (is_array($httpOptions["content"]))
                        {
                            $httpPostContent = http_build_query($httpOptions["content"], "", "&");
                        } else
                        {
                            $httpPostContent = $httpOptions["content"];
                        }

                        $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
                        $header .= "Content-Length: " . strlen($httpPostContent) . "\r\n\r\n";
                        $header .= $httpPostContent;
                    }
                }

                $header .= "\r\n";

                fwrite($handle, $header . $data);

                while (!feof($handle))
                {
                    $response .= fgets($handle, 32768);
                }

                fclose($handle);
            }
        }

        $position = strpos($response, "\r\n\r\n");
        $responseHeader = trim(substr($response, 0, $position));
        $responseBody = trim(substr($response, $position));
        $this->httpResponseHeader = explode("\r\n", $responseHeader);

        if(stripos($responseHeader, "Transfer-Encoding: chunked") !== false && $this->useCurl === false)
        {
            $responseBody = self::httpChunkedDecode($responseBody);
        }

        if ($returnRaw)
        {
            return $responseBody;
        }

        if (strpos($responseHeader, "application/json") !== false)
        {
            $data = json_decode($responseBody, true);
            $data = $data["response"];
        } elseif (strpos($responseHeader, "text/xml") !== false)
        {
            $data = self::xml2array(simplexml_load_string($responseBody));
        } else
        {
            $this->showError("Unsupported server response format");
        }

	ini_restore('memory_limit');
        if (isset($data["result"]) && trim($data["result"]) == "Success")
        {
            return $data;
        } else
        {
            $this->showError(trim($data["message"]), trim($data["error"]));
            return false;
        }
    }

    public static function httpChunkedDecode($chunk)
    {
        $pos = 0;
        $len = strlen($chunk);
        $dechunk = null;

        while(($pos < $len)
            && ($chunkLenHex = substr($chunk, $pos,
                ($newlineAt = strpos($chunk, "\n", $pos + 1)) - $pos)))
        {
            if (!self::isHex($chunkLenHex))
            {
                trigger_error("Value is not properly chunk encoded", E_USER_WARNING);
                return $chunk;
            }

            $pos = $newlineAt + 1;
            $chunkLen = hexdec(rtrim($chunkLenHex, "\r\n"));
            $dechunk .= substr($chunk, $pos, $chunkLen);
            $pos = strpos($chunk, "\n", $pos + $chunkLen) + 1;
        }

        return $dechunk;
    }

    public static function isHex($hex)
    {
        // regex is for weenies
        $hex = strtolower(trim(ltrim($hex, "0")));
        if (empty($hex)) { $hex = 0; };
        $dec = hexdec($hex);
        return ($hex == dechex($dec));
    }

    protected function showError($errorMessage, $errorCode = "0")
    {
        exit("Error - " . end($this->actions) . " : \"" . $errorMessage . "\" (" . $errorCode . ")");
    }

    public static function xml2array($xml)
    {
        $newArray = array();
        $array = (array) $xml;
        foreach($array as $key => $value)
        {
            $value = (array) $value;
            if (isset($value[0]))
            {
                if (is_object($value[0]))
                    $newArray[$key] = self::xml2array($value, true);
                else
                    $newArray[$key] = trim($value[0]);
            }
            else
            {
                $newArray[$key] = self::xml2array($value, true);
            }
        }
        return $newArray;
    }

    public static function copy()
    {
        $arguments = func_get_args();
        $array = array_shift($arguments);
        $return = null;

        if (count($arguments) > 0)
        {
            $return = array();
            foreach($arguments as $key)
            {
                if (isset($array[$key]))
                {
                    $return[$key] = $array[$key];
                }
            }
        }

        return $return;
    }

    public function userFetchTos($sessionToken)
    {
        $this->actions[] = "Fetching T.O.S document";

        $query = array(
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_FETCH_TOS"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["terms_of_service"];
    }

    public function userAcceptTos($sessionToken, $acceptanceToken)
    {
        $this->actions[] = "Accepting T.o.S document";

        $query = array(
            "session_token" => $sessionToken,
            "acceptance_token" => $acceptanceToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_ACCEPT_TOS"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return true;
    }

    protected function userGetLoginToken()
    {
        $this->actions[] = "Getting login token";

        $query = array(
            "email" => $this->email,
            "password" => $this->password,
            "application_id" => $this->appId,
            "signature" => $this->userGetSignature(),
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_GET_LOGIN_TOKEN"] . "?" . http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return trim($data["login_token"]);
    }

    public function userGetSessionToken()
    {
        $this->actions[] = "Getting new session token";

        $query = array(
            "application_id" => $this->appId,
            "signature" => $this->userGetSignature(),
            "response_format" => $this->responseFormat
        );

        if (!empty($this->fbAccessToken))
        {
            $query["fb_access_token"] = $this->fbAccessToken;
        } else
        {
            $query["email"] = $this->email;
            $query["password"] = $this->password;
        }

        $url = $this->apiUrl["USER_GET_SESSION_TOKEN"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return trim($data["session_token"]);
    }

    protected function userGetSignature()
    {
        return sha1($this->email . $this->password . $this->appId . $this->apiKey);
    }

    public function userRenewSessionToken($sessionToken)
    {
        $this->actions[] = "Renewing current session token";

        $query = array(
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_RENEW_SESSION_TOKEN"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return trim($data["session_token"]);
    }

    public function userGetInfo($sessionToken, $singleInfo = null)
    {
        $this->actions[] = "Getting user info";

        $query = array(
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_GET_INFO"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        if (is_string($singleInfo) && !empty($singleInfo))
        {
            $singleInfo = trim(strtolower($singleInfo));
            if (isset($data["user_info"]["$singleInfo"]))
            {
                return $data["user_info"]["$singleInfo"];
            }
        }

        return $data["user_info"];
    }

    public function userMyfilesRevision($sessionToken)
    {
        $this->actions[] = "Getting user Myfiles revision";

        $query = array(
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["USER_MYFILES_REVISION"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return self::copy($data, "revision", "epoch");
    }

    /*public function userRegister($email, $password, $information = null)
    {
        $this->actions[] = "Registering new user";

        if(empty($email) || empty($password))
        {
            $this->showError("User email and password are both required");
            return false;
        }

        $query = array(
            "email" => $email,
            "password" => $password,
            "application_id" => $this->appId,
            "response_format" => $this->responseFormat
        );

        $parameters = array("first_name", "last_name", "display_name");

        if (is_array($information) && !empty($information))
        {
            foreach($information as $key => $value)
            {
                $key = trim(strtolower($key));
                $value = trim($value);

                if (in_array($key, $parameters))
                {
                    $query[$key] = $value;
                }
            }
        }

        $url = $this->apiUrl["USER_REGISTER"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return true;
    }*/

    public function userUpdate($sessionToken, $information)
    {
        $this->actions[] = "Updating user information";

        $genders = array("male", "female", "none");
        $primary_usages = array("home", "work", "school", "none");
        $parameters = array("display_name", "first_name", "last_name",
                            "birth_date", "gender", "website",
                            "location", "newsletter", "primary_usage");

        $query = array(
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        if (is_array($information) && !empty($information))
        {
            foreach($information as $key => $value)
            {
                $key = trim(strtolower($key));
                $value = trim($value);
                $addTo = false;

                if (in_array($key, $parameters))
                {
                    switch ($key)
                    {
                        case "birth_date":
                            if (preg_match("/\d{4}-\d{2}-\d{2}/", $value))
                                $addTo = true;
                            break;
                        case "gender":
                            if (in_array($value, $genders))
                                $addTo = true;
                            break;
                        case "newsletter":
                            if ($value == "yes" || $value == "no")
                                $addTo = true;
                            break;
                        case "primary_usage":
                            if (in_array($value, $primary_usages))
                                $addTo = true;
                            break;
                    }
                }

                if($addTo === true)
                {
                    $query[$key] = $value;
                }
            }

            $url = $this->apiUrl["USER_UPDATE"] . "?" . http_build_query($query, "", "&");
            $data = $this->getContents($url);

            if (!$data)
            {
                return false;
            }

            return true;
        }
    }

    public function fileCollaborate($sessionToken, $quickkey = null,
        $emails = null, $duration = null, $message = null, $public = null,
        $emailNotification = null)
    {
        $this->actions[] = "Generating collaboration links";

        if (!empty($quickkey))
        {
            if (is_array($quickkey))
            {
                $quickkey = implode(",", $quickkey);
            }

            if (!empty($emails))
            {
                $message = null;
            } else
            {
                if (is_array($emails))
                {
                    $emails = implode(",", $emails);
                }
            }

            if (!is_int($duration))
            {
                $duration = null;
            }

            if ($public === false || $public == 0)
            {
                $public = "no";
            } else
            {
                $public = "yes";
            }
        }

        $query = array(
            "quick_key" => $quickkey,
            "emails" => $emails,
            "duration" => $duration,
            "message" => $message,
            "public" => $public,
            "email_notification" => $emailNotification,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_COLLABORATE"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return self::copy($data, "collaboration_links", "daily_sharing_count");
    }

    public function fileCopy($sessionToken, $quickkey, $folderKey = null)
    {
        $this->actions[] = "Copying file";

        if (is_array($quickkey))
        {
            $quickkey = implode(",", $quickkey);
        }

        $query = array(
            "quick_key" => $quickkey,
            "folder_key" => ($folderKey != "")
                            ? $folderKey : null,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_COPY"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["skipped_count"];
    }

    public function fileDelete($sessionToken, $quickkey)
    {
        $this->actions[] = "Deleting file";

        if (is_array($quickkey))
        {
            $quickkey = implode(",", $quickkey);
        }

        $query = array(
            "quick_key" => $quickkey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_DELETE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function fileGetInfo($sessionToken, $quickkey)
    {
        $this->actions[] = "Getting file information";

        if (is_array($quickkey))
        {
            $quickkey = implode(",", $quickkey);
        }

        $query = array(
            "quick_key" => $quickkey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_GET_INFO"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        if(strpos($quickkey, ",") !== false)
        {
            return $data["file_infos"];
        } else
        {
            return $data["file_info"];
        }
    }

    public function fileGetLinks($quickkey, $linkType = null,
        $sessionToken = null)
    {
        $this->actions[] = "Get file links";

        if (is_array($quickkey))
        {
            $quickkey = implode(",", $quickkey);
        } elseif (!is_string($quickkey))
        {
            $this->showError("Invalid parameter 'quickkey' specified");
            return false;
        }

        $linkType = trim(strtolower($linkType));
        $linkTypes = array("view", "edit", "normal_download",
            "direct_download", "one_time_download");
        if (!is_string($linkType) || !in_array($linkType, $linkTypes))
        {
            $linkType = null;
        }

        $query = array(
            "quick_key" => $quickkey,
            "link_type" => $linkType,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_GET_LINKS"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return self::copy($data, "links",
            "one_time_download_request_count",
            "direct_download_free_bandwidth");

        return $return;
    }

    public function fileMove($sessionToken, $quickkey, $folderKey = null)
    {
        $this->actions[] = "Moving file";

        if (is_array($quickkey))
        {
            $quickkey = implode(",", $quickkey);
        }

        $query = array(
            "quick_key" => $quickkey,
            "folder_key" => ($folderKey != "")
                            ? $folderKey : null,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_MOVE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function fileOneTimeDownload($sessionToken, $quickkey, $information)
    {
        if (strlen($quickkey) < 16)
        {
            $this->actions[] = "Creating a one-time download link";
            $param = "quick_key";
            $url = $this->apiUrl["FILE_ONE_TIME_DOWNLOAD"];
        } else
        {
            $this->actions[] = "Configuring a one-time download link";
            $url = $this->apiUrl["FILE_CONFIGURE_ONE_TIME_DOWNLOAD"];
            $param = "token";
        }


        $query = array(
            $param => $quickkey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $parameters = array("get_counts_only", "duration", "email_notification",
                            "success_callback_url", "error_callback_url", "bind_ip",
                            "burn_after_use");

        if (is_array($information) && !empty($information))
        {
            foreach($information as $key => $value)
            {
                $key = trim(strtolower($key));
                $value = trim($value);

                if (in_array($key, $parameters))
                {
                    $query[$key] = $value;
                }
            }
        }

        $url .= "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        if (strlen($quickkey) < 16)
        {
            return self::copy($data, "one_time_download_request_count",
                "one_time_download", "token");
        } else
        {
            return $data["one_time_download_request_count"];
        }
    }

    public function fileUpdateInfo($sessionToken, $quickkey, $information)
    {
        $this->actions[] = "Updating file information";

        $query = array(
            "quick_key" => $quickkey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $parameters = array("filename", "description", "tags",
                            "privacy", "note_subject", "note_description",
                            "timezone");

        if (is_array($information) && !empty($information))
        {
            foreach($information as $key => $value)
            {
                $key = trim(strtolower($key));
                $value = trim($value);

                if (in_array($key, $parameters))
                {
                    $query[$key] = $value;
                }
            }
        }

        $url = $this->apiUrl["FILE_UPDATE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function fileUpdate($sessionToken, $fromQuickkey, $toQuickkey)
    {
        $this->actions[] = "Updating file's quickey";

        $query = array(
            "from_quickkey" => $fromQuickkey,
            "to_quickkey" => $toQuickkey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_UPDATE_FILE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function fileUpdatePassword($sessionToken, $quickkey, $password = null)
    {
        $this->actions[] = "Updating file password";

        $query = array(
            "quick_key" => $quickkey,
            "password" => $password,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_UPDATE_PASSWORD"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function fileUpload($sessionToken, $filename, $uploadKey = "myfiles",
        $customName = null)
    {
        $mimetype = "application/octet-stream";
        if(strpos($filename, ";type=") !== false)
        {
            $parts = explode(";type=", $filename, 2);
            $filename = $parts[0];
            if (!empty($parts[1]))
            {
                $mimetype = $parts[1];
            }
        }

        if (!file_exists($filename) || !is_readable($filename))
        {
            $this->showError("File is not exist or not readable");
            return false;
        }

        $filesize = filesize($filename);
        if ($filesize == 0)
        {
            $this->showError("File has no content");
            return false;
        }

        $httpOptions = array(
            "method" => "POST",
            "file" => array(
                "name" => "Filedata",
                "path" => $filename,
                "type" => $mimetype
            ),
            "header" => array(
                "Referer: http://www.mediafire.com",
                "x-filesize: $filesize"
            )
        );

        if (is_string($customName) && !empty($customName))
        {
            $httpOptions["header"][] = "x-filename: $customName";
        }

        $query = array(
            "uploadkey" => $uploadKey,
            "session_token" => $sessionToken,
            "response_format" => "xml"
        );

        $this->actions[] = "Uploading";
        $url = $this->apiUrl["FILE_UPLOAD"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url, $httpOptions);

        if (!$data)
        {
            return false;
        }

        if (!isset($data["doupload"]["key"]) || trim($data["doupload"]["key"]) == "")
        {
            $this->showError("Unable to upload file - Code '" . $data["doupload"]["result"] . "'");
        }

        return $data["doupload"]["key"];
    }

    public function filePollUpload($sessionToken, $uploadKey)
    {
        if (!is_string($sessionToken) || empty($sessionToken))
            return false;

        $this->actions[] = "Getting upload result";
        $query = array(
            "session_token" => $sessionToken,
            "key" => $uploadKey,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FILE_UPLOAD_POLL"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

		$data["doupload"]["result_message"] = "";
		if (isset($this->uploadResult[$data["doupload"]["result"]]))
		{
			$data["doupload"]["result_message"] = $this->uploadResult[$data["doupload"]["result"]];
		}

		$data["doupload"]["fileerror_message"] = "";
		if (isset($this->uploadFileError[$data["doupload"]["fileerror"]]))
		{
			$data["doupload"]["fileerror_message"] = $this->uploadFileError[$data["doupload"]["fileerror"]];
		}

        return $data["doupload"];
    }

    public function folderAttachForeign($sessionToken, $folderKey)
    {
        if (is_array($folderKey))
        {
            $folderKey = implode(",", $folderKey);
        }

        $this->actions[] = "Adding shared folder";
        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_ATTACH_FOREIGN"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function folderCreate($sessionToken, $folderName, $parentKey = null)
    {
        $this->actions[] = "Creating new folder";

        $query = array(
            "foldername" => $folderName,
            "parent_key" => ($parentKey != "") ? $parentKey : null,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_CREATE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return self::copy($data, "folder_key", "upload_key", "created");
    }

    public function folderDetachForeign($sessionToken, $folderKey)
    {
        if (is_array($folderKey))
        {
            $folderKey = implode(",", $folderKey);
        }

        $this->actions[] = "Removing shared folder";
        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_DETACH_FOREIGN"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function folderDelete($sessionToken, $folderKey)
    {
        if (is_array($folderKey))
        {
            $folderKey = implode(",", $folderKey);
        }

        $this->actions[] = "Deleting folder";
        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_DELETE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function folderGetContent($folderKey = null, $sessionToken = null,
        $contentType = "folders", $orderBy = null, $orderDirection = null, $chunk = null)
    {
        $this->actions[] = "Getting folder contents";

        if (empty($folderKey) && empty($sessionToken))
        {
            return false;
        }

        if (!($contentType == "folders" || $contentType == "files"))
        {
            $contentType = "folders";
        }

        $orderBy = trim(strtolower($orderBy));
        $orderBys = array("name", "created", "size", "downloads");
        if (!is_string($orderBy) || !in_array($orderBy, $orderBys))
        {
            $orderBy = null;
        }

        if (!($orderDirection == "asc" || $orderDirection == "desc"))
        {
            $orderDirection = null;
        }

        if (!is_int($chunk))
        {
            $chunk = null;
        }

        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "content_type" => $contentType,
            "order_by" => $orderBy,
            "order_direction" => $orderDirection,
            "chunk" => $chunk,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_GET_CONTENT"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return $data["folder_content"];
    }

    public function folderGetDepth($sessionToken, $folderKey)
    {
        $this->actions[] = "Getting folder distance from root";

        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_GET_DEPTH"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return $data["folder_depth"];
    }

    public function folderGetInfo($folderKey, $sessionToken)
    {
        if (is_array($folderKey))
        {
            $folderKey = implode(",", $folderKey);
        }

        $this->actions[] = "Getting folder information";
        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_GET_INFO"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        if(strpos($folderKey, ",") !== false)
        {
            return $data["folder_infos"];
        } else
        {
            return $data["folder_info"];
        }
    }

    public function folderGetRevision($sessionToken, $folderKey)
    {
        $this->actions[] = "Getting folder's revision";

        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_GET_REVISION"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return self::copy($data, "revision", "epoch");
    }

    public function folderGetSiblings($folderKey, $sessionToken = null,
        $contentFilter = "all", $start = null, $limit = null)
    {
        $this->actions[] = "Getting folder sibling";

        $contentFilter = trim(strtolower($contentFilter));
        $contentFilters = array("info", "files", "folders", "content", "all");
        if (!is_string($contentFilter) || !in_array($contentFilter, $contentFilters))
        {
            $contentFilter = "all";
        }

        if (!is_int($start))
        {
            $start = null;
        }

        if (!is_int($limit))
        {
            $limit = null;
        }

        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "content_filter" => $contentFilter,
            "start" => $start,
            "limit" => $limit,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_GET_SIBLINGS"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return self::copy($data, "siblings");
    }

    public function folderMove($sessionToken, $folderKeySrc, $folderKeyDst = null)
    {
        if (is_array($folderKeySrc))
        {
            $folderKeySrc = implode(",", $folderKeySrc);
        }

        $this->actions[] = "Moving folder";
        $query = array(
            "folder_key_src" => $folderKeySrc,
            "folder_key_dst" => ($folderKeySrc != "")
                                ? $folderKeyDst : null,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_MOVE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function folderSearch($searchText, $folderKey = null,
        $sessionToken = null)
    {
        $this->actions[] = "Searching folder contents";

        if (empty($folderKey) && empty($sessionToken))
        {
            return false;
        }

        $query = array(
            "search_text" => $searchText,
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["FOLDER_SEARCH"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);
        if (!$data)
        {
            return false;
        }

        return self::copy($data, "results_count", "results");
    }

    public function folderUpdate($sessionToken, $folderKey, $information)
    {
        $this->actions[] = "Updating folder's information";

        $query = array(
            "folder_key" => $folderKey,
            "session_token" => $sessionToken,
            "response_format" => $this->responseFormat
        );

        $parameters = array("foldername", "description", "tags", "privacy",
                            "privacy_recursive", "note_subject", "note_description");

        if (is_array($information) && !empty($information))
        {
            foreach($information as $key => $value)
            {
                $key = trim(strtolower($key));
                $value = trim($value);

                if (in_array($key, $parameters))
                {
                    $query[$key] = $value;
                }
            }
        }

        $url = $this->apiUrl["FOLDER_UPDATE"] . "?" . http_build_query($query, "", "&");
        $data = $this->getContents($url);

        if (!$data)
        {
            return false;
        }

        return $data["myfiles_revision"];
    }

    public function systemVersion()
    {
        $this->actions[] = "Getting API version";
        $query = array(
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["SYSTEM_GET_VERSION"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);

        return $data["current_api_version"];
    }

    public function systemInfo()
    {
        $this->actions[] = "Getting MediaFire system information";
        $query = array(
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["SYSTEM_GET_INFO"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);

        return self::copy($data, "current_api_version", "viewable", "editable",
            "image_sizes", "max_keys", "max_objects", "max_image_size");
    }

    public function systemSupportedMedia($groupByFiletype = false)
    {
        $this->actions[] = "Getting supported document types for preview list";

        if ($groupByFiletype == false || $groupByFiletype == 0)
        {
            $groupByFiletype = "no";
        } else
        {
            $groupByFiletype = "yes";
        }

        $query = array(
            "group_by_filetype" => $groupByFiletype,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["SYSTEM_GET_SUPPORTED_MEDIA"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);

        return $data["viewable"];
    }

    public function systemEditableMedia($groupByFiletype = false)
    {
        $this->actions[] = "Getting supported document types for editting";

        if ($groupByFiletype == false || $groupByFiletype == 0)
        {
            $groupByFiletype = "no";
        } else
        {
            $groupByFiletype = "yes";
        }

        $query = array(
            "group_by_filetype" => $groupByFiletype,
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["SYSTEM_GET_EDITABLE_MEDIA"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);

        return $data["editable"];
    }

    public function systemMimeTypes()
    {
        $this->actions[] = "Getting MIME type list";

        $query = array(
            "response_format" => $this->responseFormat
        );

        $url = $this->apiUrl["SYSTEM_GET_MIME_TYPES"] . "?" .
            http_build_query($query, "", "&");

        $data = $this->getContents($url);

        return $data["mime_types"];
    }

    public function mediaConversion($sessionToken, $quickkey, $saveAs = null,
        $sizeId = "2", $page = "initial", $output = "pdf")
    {
        $this->actions[] = "Converting file";

        $fileInfo = $this->fileGetInfo($sessionToken, $quickkey);
        if (!$fileInfo)
        {
            $this->showError("Failed to get file information before conversion");
            return false;
        }

        if ($fileInfo["filetype"] == "document")
        {
            $docType = "d";

            $outputs = array("pdf", "swf", "img");
            if (!in_array($output, $outputs))
            {
                $output = "pdf";
            }

            if (!is_int($page) && $page != "initial")
            {
                $page = "initial";
            }
        } elseif ($fileInfo["filetype"] == "image")
        {
            $docType = "i";
            $output = $page = null;
        } else
        {
            $this->showError("File format is not supported");
            return false;
        }

        if (!in_array($sizeId, $this->mcSizeId[$docType]))
        {
            $sizeId = "2";
        }

        $query = array(
            "quickkey" => $quickkey,
            "page" => $page,
            "doc_type" => $docType,
            "output" => $output,
            "size_id" => $sizeId
        );

        $url = $this->apiUrl["MEDIA_CONVERSION"] . "?" . substr($fileInfo["hash"], 0, 4)
            . "&" . http_build_query($query, "", "&");

        $data = $this->getContents($url, null, true);
        $statusCode = preg_match("/ ([0-9]+)/", $this->httpResponseHeader[0], $match);

        switch($match[1])
        {
            case "200":
                if (is_string($saveAs))
                {
                    $length = file_put_contents($saveAs, $data);
                    if ($length === false)
                    {
                        $this->showError("Failed to write data to file");
                        return false;
                    }

                    return $length;
                } else
                {
                    return $data;
                }
            case "202":
                return true;
            case "204":
            case "400":
            case "404":
                $this->showError($this->mcStatusCode[$match[1]], $match[1]);
                return false;
        }
    }
}
?>