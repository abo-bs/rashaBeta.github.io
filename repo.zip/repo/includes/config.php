<?php global $config;
$config["url"] = "http://repo.goldencydia.org/";
$config["nom"] = "Golden Cydia Repository";