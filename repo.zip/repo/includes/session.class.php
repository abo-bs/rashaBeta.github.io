<?php require_once('functions.php');
class Session {
	protected $salt = 'Qk4ivoJ_g0%gzOoiDNZg~2s9TcqdsK*RIo_DbGU+JUsOQFX5FdrSRVelQUYO';
	protected $salt2 = 'PKEIzCPSkEtJoaGMMY*8905b6ilLvNbqFfVyzNmzAEeGt~ ZNKF9iJ=xMdDU';
	protected $salt3 = 'F|~eLg=pZdQFPN=yDmIbU+xFd*YCQ9Dn74Zd+JS_pY7T4CjwAa^B4-kktW5v';
	private static $_tableMembre = array('id', 'pseudo', 'mail', 'password', 'level', 'date', 'last_date', 'ip', 'recovery');
	public $_id, $_pseudo, $_connected, $_password, $_mail, $_level, $_token;
	public function __construct() {
		if(isset($_COOKIE["PHPSESSID"]))
			session_start();
		if(isset($_SESSION['connected'])) {
			$this->_connected = $_SESSION['connected'];
			$this->_id = $_SESSION['id'];
			$this->_pseudo = strtolower($_SESSION['pseudo']);
			$this->_level = $_SESSION['level'];
			$this->_token = $_SESSION['token'];
		} else {
			if(!empty($_COOKIE['autologin'])) {
				$logins = explode('|', $_COOKIE['autologin']);
				$id = trim($logins[0]);
				$hash = trim($logins[1]);
				if(!$this->autologin($id, $hash))
					$this->delete();
			} else
				$this->delete();
		}
	}
	public function connexion($pseudo, $password, $encrypted = false, $persistant = false) {
		if(!$encrypted)
			$password = $this->hash($password);
		$pdo = PDO2::getInstance();
		$query = $pdo->prepare('SELECT id, pseudo, level FROM membre WHERE password = :password AND pseudo = :pseudo');
		try {
			$query->execute(array(':pseudo' => $pseudo, ':password' => $password));
			$count = $query->rowCount();
			$results = $query->fetch(PDO::FETCH_ASSOC);
			$query->closeCursor();
			$pdo = PDO2::closeInstance();
			if($count == 1) {
				session_start();
				if(isset($_COOKIE['PHPSESSID']))
					$token = $_COOKIE['PHPSESSID'];
				else {
					$chaine = "abcdefghijklmnpqrstuvwxyz0123456789";
					$nb_chars = strlen($chaine);
					for($i=0; $i < 26; $i++) {
						$token .= $chaine[ rand(0, ($nb_chars-1)) ];
					}
				}
				$this->_connected = $_SESSION['connected'] = true;
				$this->_id = $_SESSION['id'] = $results['id'];
				$this->_pseudo = $_SESSION['pseudo'] = $results['pseudo'];
				$this->_level = $_SESSION['level'] = $results['level'];
				$this->_token = $_SESSION['token'] = $token;
				if($persistant)
					setrawcookie('autologin', $results['id'].'|'.$this->hash($this->salt.$pseudo.$this->salt2.$password.$this->salt3), time() + 3600 * 24 * 360, '/');
				session_write_close();
				return true;
			} else {
				return false;
			}
		} catch(Exception $e) {
			$this->delete();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	public function autologin($id, $hash) {
		$pdo = PDO2::getInstance();
		$query = $pdo->prepare('SELECT pseudo, password, level FROM membre WHERE id = :id');
		try {
			$query->execute(array(':id' => $id));
			$count = $query->rowCount();
			$results = $query->fetch(PDO::FETCH_ASSOC);
			$query->closeCursor();
			$pdo = PDO2::closeInstance();
			if($count == 1 && $hash == $this->hash($this->salt.$results['pseudo'].$this->salt2.$results['password'].$this->salt3)) {
				session_start();
				if(isset($_COOKIE['PHPSESSID']))
					$token = $_COOKIE['PHPSESSID'];
				else {
					$chaine = "abcdefghijklmnpqrstuvwxyz0123456789";
					$nb_chars = strlen($chaine);
					for($i=0; $i < 26; $i++) {
						$token .= $chaine[ rand(0, ($nb_chars-1)) ];
					}
				}
				$this->_connected = $_SESSION['connected'] = true;
				$this->_id = $_SESSION['id'] = $id;
				$this->_pseudo = $_SESSION['pseudo'] = $results['pseudo'];
				$this->_level = $_SESSION['level'] = $results['level'];
				$this->_token = $_SESSION['token'] = $token;
				session_write_close();
				return true;
			} else {
				return false;
			}
		} catch(Exception $e) {
			$this->delete();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	public function getInfo($ligne) {
		$pdo = PDO2::getInstance();
		$req = (is_array($ligne)) ? implode('`, `', $ligne) : $ligne;
		$req = $pdo->prepare("SELECT `$req` FROM membre WHERE id = :id LIMIT 1");
		try {
			$req->execute(array(':id' => $this->_id));
			if(is_array($ligne))
				$retour = $req->fetch(PDO::FETCH_ASSOC);
			else
				$retour = $req->fetchColumn();
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			if($retour != NULL && !empty($retour))
				return $retour;
			else
				return false;
		} catch(Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
			return false;
		}
	}
	public function setInfo($text, $ligne) {
		$pdo = PDO2::getInstance();
		if(empty($text) || $text == false && $text !== 0)
			$text = '';
		if(in_array(strtolower($ligne), self::$_tableMembre))
			$table = 'membre';
		else
			return;
		$req = $pdo->prepare("INSERT INTO $table (id, `$ligne`) VALUES (:id, :text)
		ON DUPLICATE KEY UPDATE `$ligne` = :text");
		try {
			$req->execute(array(':id' => $this->_id, ':text' => $text));
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		} catch (Exception $e) {
			$req->closeCursor();
			$pdo = PDO2::closeInstance();
		}
	}
	public function hash($variable) {
		return hash('sha512', hash('sha512', $variable));
	}
	public function tweet($message) {
		$twitter = unserialize($this->getInfo('twitter'));
		if(!empty($twitter)) {
			require_once('includes/twitteroauth.php');
			$tweet = new TwitterOAuth(config('consumer-key'), config('consumer-secret'), $twitter['oauth_token'], $twitter['oauth_token_secret']);
			if(!empty($message)) {
				$tweet->post('statuses/update',array('status' => $message));
				switch ($tweet->http_code) {
					case '200':
					case '304':
						return true;
						break;
					case '400':
					case '401':
					case '403':
					case '404':
					case '406':
						return false;
						break;
					default:
						return false;
				}
			} else
				return false;
		} else
			return false;
	}
	public function update() {
		$pdo = PDO2::getInstance();
		$req = $pdo->prepare('INSERT INTO membre (id, ip, `last_date`) VALUES (:id, ip, CURRENT_TIMESTAMP)
		ON DUPLICATE KEY UPDATE ip = :ip, `last_date` = CURRENT_TIMESTAMP');
		$req->execute(array(':id' => $this->_id, ':ip' => getIp()));
		$req->closeCursor();
		$pdo = PDO2::closeInstance();
	}
	public static function checkSettings($settings, $default, $reset = false) {
		if(!$reset && isset($_COOKIE['settings|'.$settings])) {
			return unserialize(base64_decode($_COOKIE['settings|'.$settings]));
		} else {
			$params = session_get_cookie_params();
			if(type_device() != 'iPod' && type_device() != 'iPhone' && type_device() != 'iPad')
				setrawcookie('settings|'.$settings, base64_encode(serialize($default['computer'])), time() + 3600 * 24 * 360, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
			else
				setrawcookie('settings|'.$settings, base64_encode(serialize($default['mobile'])), time() + 3600 * 24 * 360, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
		}
	}
	public static function setSettings($settings) {
		$params = session_get_cookie_params();
		setrawcookie('settings|'.$settings, base64_encode(serialize($_POST)), time() + 3600 * 24 * 360, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
	}
	public function deconnecte() {
		$pdo = PDO2::getInstance();
		$update_user = $pdo->prepare('INSERT INTO membre (id, `last_date`) VALUES (:id, CURRENT_TIMESTAMP)
		ON DUPLICATE KEY UPDATE `last_date` = CURRENT_TIMESTAMP');
		$update_user->execute(array(':id' => $this->_id));
		$update_user->closeCursor();
		if(is_dir('temp/'.$this->_pseudo))
			rrmdir('temp/'.$this->_pseudo);
		if(file_exists('temp/'.$this->_pseudo.'.deb'))
			unlink('temp/'.$this->_pseudo.'.deb');
		$this->delete();
		$pdo = PDO2::closeInstance();
	}
	public function delete() {
		if(ini_get('session.use_cookies')) {
			$params = session_get_cookie_params();
			setrawcookie(session_name(), NULL, -42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
		}
		@session_destroy();
		setrawcookie('autologin', NULL, -42000, '/');
		unset($this->_connected);
	}
}