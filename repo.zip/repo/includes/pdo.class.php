<?php 
class PDO2 extends PDO {
	private static $_instance;
	/* Constructeur : héritage public obligatoire par héritage de PDO */
	public function __construct( ) {
	}
	public static function getInstance() {
		if (!isset(self::$_instance)) {
			try {
				self::$_instance = new PDO('mysql:host=176.32.230.47;dbname=cl59-repogc', 'cl59-repogc', 'wh^cHCrCD', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8", PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			} catch (PDOException $e) {
				echo "<h1>Unable to connect to database.</h1>";
				echo "<h3>Thank you to report this problem to the administrator</h3>";
				// echo "<br/>Error : <i>".$e->getMessage()."</i>";
				exit();
			}
		}
		return self::$_instance;
	}
	public static function closeInstance() {
		return self::$_instance = null;
	}

}