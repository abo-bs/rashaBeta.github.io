<?php
if(!isset($membre->_id)) {
	$membre->delete();
	header('Location: /404.php');
	exit;
}
$check_user = $membre->getInfo(array('last_date', 'level', 'ip'));
if(!isset($check_user['last_date']) || !isset($check_user['level']) || !isset($check_user['ip'])) {
	$membre->delete();
	header('Location: /404.php');
	exit;
}
if($membre->_level != $check_user['level']) {
	$membre->_level = $_SESSION['level'] = $check_user['level'];
	header('Location: /login.php');
	exit;
}
if(getIp() != $check_user['ip']) {
	$membre->update();
	if(!$_COOKIE['autologin']) {
		$membre->deconnecte();
		header('Location: /login.php?timeout');
		exit;
	}
}

if($check_user['last_date'] < date('Y-m-d H:i', time() - 60)) {
	$membre->update();
}
unset($check_user); ?>